<?php
    session_start();

    $_SESSION['token'] = bin2hex(random_bytes(24));
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>
    <body>
        <p style="color: red">
            <?php
            if(isset($_GET['error'])){
                echo "Une erreur est survenue, veuillez réessayer !";
            }
            ?>
        </p>
        <h1>
            <?php 
                if(!isset($_SESSION["user"])){
                    echo "CONNECTEZ-VOUS !";
                    
                }
                else{
                    echo "BIENVENUE ".$_SESSION['user']['username'];
                    echo " <a href='logout.php'>Déconnexion</a>";
                }
            ?>
        </h1>
        <form method="post" action="connexion.php">
            
            <input type="text" placeholder="Votre login" name="username"><br>
            
            <input type="password" placeholder="Votre mot de passe" name="password"><br>

            <input type="hidden" value="<?= $_SESSION['token']?>" name="token">
    
            <input type="submit" value="Connexion"><i id="loading" class="fas fa-spinner fa-2x fa-spin" style="display: none;"></i>
            
        </form>
        <script src="https://kit.fontawesome.com/1e5edb27fe.js" crossorigin="anonymous"></script>
        <script
          src="https://code.jquery.com/jquery-3.4.1.min.js"
          integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
          crossorigin="anonymous"></script>
        <script>
            $("form").submit(function(){
                $("#loading").show();
            })
        </script>
    </body>
</html>