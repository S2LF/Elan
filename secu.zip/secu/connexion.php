<?php
    require_once("dbconnect.php");
    require_once("Connector.php");

    session_start();

    $connector = new Connector($connexion);

    $user = $connector->getUser($_POST['username']);

    if(
        is_array($user) &&
        $connector->verifyPassword($_POST['password']) && 
        hash_equals($_SESSION['token'], $_POST['token'])
    ){
        $_SESSION['user'] = $user;
        header("Location:index.php");
    }
    else header("Location:index.php?error");


